package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.adapter.adapterHoadonchitiet;
import com.example.myapplication.adapter.adaterHoaDon;
import com.example.myapplication.dao.HoaDondao;
import com.example.myapplication.dao.Hoadonchitietdao;
import com.example.myapplication.model.Hoadonchitiet;

import java.util.ArrayList;

public class hoadonchitiet_activity extends AppCompatActivity {
RecyclerView rcvhdct;
Button btnthanhtoan,btnthem;
EditText mahoadon,etmamusic;
adapterHoadonchitiet adapter;
ArrayList<Hoadonchitiet> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoadonchitiet_activity);
        rcvhdct=findViewById(R.id.rcvhoadonct);
        RecyclerView.LayoutManager layoutManager= new LinearLayoutManager(hoadonchitiet_activity.this);
        rcvhdct.setLayoutManager(layoutManager);
        list=new ArrayList<>();
        list= Hoadonchitietdao.reaAll(hoadonchitiet_activity.this);
        adapter=new adapterHoadonchitiet(hoadonchitiet_activity.this,list);
        rcvhdct.setAdapter(adapter);

    }
}