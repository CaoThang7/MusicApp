package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.myapplication.music.MusicActivity;
import com.example.myapplication.theloai.TheLoaiActivity;
import com.example.myapplication.user.nguoidungactivity;

public class giaodienoption extends AppCompatActivity {
    ImageView ivuser,ivmusic,ivthememusic,ivkobk,ivthongke,ivbuy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giaodienoption);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ivuser=findViewById(R.id.ivgd1);
        ivmusic=findViewById(R.id.ivgd2);
        ivthememusic=findViewById(R.id.ivgd3);
        ivkobk=findViewById(R.id.ivgd4);
        ivthongke=findViewById(R.id.ivgd5);
        ivbuy=findViewById(R.id.ivgd6);
        ivuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(giaodienoption.this, nguoidungactivity.class);
                startActivity(i);
            }
        });
        ivthememusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(giaodienoption.this, TheLoaiActivity.class);
                startActivity(i);
            }
        });
        ivmusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(giaodienoption.this, MusicActivity.class);
                startActivity(i);
            }
        });
        ivkobk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(giaodienoption.this,Hoadon_activity.class);
                startActivity(i);
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return super.onCreateOptionsMenu(menu);

    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()== R.id.refresh) {
            Intent i = new Intent(giaodienoption.this, thongtinActivity.class);
            startActivity(i);
            Toast.makeText(this, "Thông tin", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId()== R.id.dmk) {
            Toast.makeText(this, "dmk", Toast.LENGTH_SHORT).show();
            Intent i=new Intent(giaodienoption.this,chanceMK.class);
            startActivity(i);
        }
        if(item.getItemId()== R.id.gioithieu)
            Toast.makeText(this,"gioi thieu",Toast.LENGTH_SHORT).show();

        if(item.getItemId()== R.id.out) {
            Toast.makeText(this, "out", Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }
}
