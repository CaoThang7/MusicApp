package com.example.myapplication.model;

public class Hoadonchitiet {
    int mahoadonchitiet;
    String mahoadon;
    int masach;
    double giabia;


    public Hoadonchitiet() {
    }

    public Hoadonchitiet(String mahoadon,int masach,double giabia) {
        this.masach = masach;
        this.giabia = giabia;
        this.mahoadon=mahoadon;

    }

    public Hoadonchitiet(int mahoadonchitiet,String mahoadon, int masach, double giabia) {
        this.mahoadonchitiet = mahoadonchitiet;
        this.masach = masach;
        this.giabia = giabia;

    }

    public String getMahoadon() {
        return mahoadon;
    }

    public void setMahoadon(String mahoadon) {
        this.mahoadon = mahoadon;
    }

    public int getMahoadonchitiet() {
        return mahoadonchitiet;
    }

    public void setMahoadonchitiet(int mahoadonchitiet) {
        this.mahoadonchitiet = mahoadonchitiet;
    }

    public int getMasach() {
        return masach;
    }

    public void setMasach(int masach) {
        this.masach = masach;
    }


    public double getGiabia() {
        return giabia;
    }

    public void setGiabia(double giabia) {
        this.giabia = giabia;
    }


}
