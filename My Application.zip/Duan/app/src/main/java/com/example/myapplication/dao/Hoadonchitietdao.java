package com.example.myapplication.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.myapplication.dhhelper.DBhelper;
import com.example.myapplication.model.Hoadonchitiet;

import java.util.ArrayList;

public class Hoadonchitietdao {
    public static ArrayList<Hoadonchitiet> reaAll(Context context){
        ArrayList<Hoadonchitiet> data=new ArrayList<>();
        DBhelper dBhelper=new DBhelper(context);
        SQLiteDatabase db=dBhelper.getReadableDatabase();
//        Cursor cs=db.rawQuery("SELECT * FROM HOADONCHITIET " +
//                "JOIN HOADON ON MaHoaDon=MaHD_Fk " +
//                "JOIN MUSIC ON MaMusic=MaMusic_FK", null);
        Cursor cs=db.rawQuery("SELECT * FROM HOADONCHITIET", null);
        cs.moveToFirst();
        while(!cs.isAfterLast()){
            try {
                int ma = cs.getInt(0);
                String mahoadon = cs.getString(1);
                int maMusuc=cs.getInt(2);
                double gia=cs.getDouble(3);
                data.add(new Hoadonchitiet(ma,mahoadon,maMusuc,gia));
                cs.moveToNext();
            }catch (Exception ex){
                Log.e("Loi", "thua");
            }

        }
        cs.close();
        return data;
    }

}
