package com.example.myapplication;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.myapplication.dao.Quantridao;
import com.example.myapplication.model.User;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import static com.example.myapplication.MainActivity.USER;

public class thongtinActivity extends AppCompatActivity {
    ArrayList<User> list;
    Quantridao dao;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thongtin);
        Toolbar toolbar=findViewById(R.id.toolbar3);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    TextView tvname,tvngya,tvphone,tvemail,tvusername,tvpassword;
        tvname=findViewById(R.id.tvten);
        tvngya=findViewById(R.id.tvngaysinh);
        tvphone=findViewById(R.id.tvphone);
        tvemail=findViewById(R.id.tvemail);
        tvusername=findViewById(R.id.tvnusername);
        tvpassword=findViewById(R.id.tvpass);
        dao=new Quantridao(thongtinActivity.this);
        list=new ArrayList<>();
        list= dao.readAll(new User(USER.getUsername(),USER.getPassword()));
        for(int i=0;i<list.size();i++){
            try {
                Toast.makeText(thongtinActivity.this, "da tim thay", Toast.LENGTH_SHORT).show();
                if (USER.getUsername().equals(list.get(i).getUsername()) && USER.getPassword().equals(list.get(i).getPassword())) {

                    SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");
                    tvname.setText(list.get(i).getTen());
                    tvngya.setText((sdf.format(list.get(i).getNgay())));
                    tvphone.setText(String.valueOf(list.get(i).getPhone()));
                    tvemail.setText(list.get(i).getEmail());
                    tvusername.setText(list.get(i).getUsername());
                    tvpassword.setText(list.get(i).getPassword());
                }
            }catch (Exception ex){}
        }


    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
}}