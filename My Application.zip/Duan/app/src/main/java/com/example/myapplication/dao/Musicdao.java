package com.example.myapplication.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.dhhelper.DBhelper;
import com.example.myapplication.model.Music;
import com.example.myapplication.model.TheLoai;
import com.example.myapplication.model.User;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Musicdao {
    public static ArrayList<Music> readAll(Context context){
        ArrayList<Music> list=new ArrayList<>();
        DBhelper dBhelper=new DBhelper(context);
        SQLiteDatabase db=dBhelper.getReadableDatabase();
        Cursor cs=db.rawQuery("SELECT * FROM MUSIC", null);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int matl=cs.getInt(0);
            String chude=cs.getString(1);
            String tenmusic=cs.getString(2);
            String tacgia=cs.getString(3);
            int gia=cs.getInt(4);
            String img=cs.getString(5);
            list.add(new Music(matl,chude,tenmusic,tacgia,gia,img));
            cs.moveToNext();

        }
        cs.close();
        return list;
    }
    public static boolean update(Context context,Music music) {
        DBhelper dbhelper = new DBhelper(context);
        SQLiteDatabase db = dbhelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("ChudeMusic",music.getChude());
        values.put("tenMusic",music.getTitle());
        values.put("tacgia",music.getTacgia());
        values.put("giasanpham",music.getGiamusic());
        values.put("file",music.getFile());
        int row = db.update("MUSIC", values, "MaMusic=?", new String[]{String.valueOf(music.getManhac())});
        if (row > 0) {
            return true;
        } else {
            return false;
        }
    }
public static boolean create(Context context,Music music){
    DBhelper dBhelper=new DBhelper(context);
    SQLiteDatabase db=dBhelper.getReadableDatabase();
    ContentValues values=new ContentValues();
    values.put("ChudeMusic",music.getChude());
    values.put("tenMusic",music.getTitle());
    values.put("tacgia",music.getTacgia());
    values.put("giasanpham",music.getGiamusic());
    values.put("file",music.getFile());

    long row=db.insert("MUSIC",null,values);
    if (row > 0) {
        return true;
    } else {
        return false;
    }
}


}
