package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class bai3 extends AppCompatActivity {
ImageView ivhour,ivminute,ivsecond;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai3);
        ivhour=findViewById(R.id.hour);
        ivminute=findViewById(R.id.minute);
        ivsecond=findViewById(R.id.second);
        makeAnimation(ivhour,R.anim.rotation,3600000*12);
        makeAnimation(ivminute,R.anim.rotation,60000*60);
        makeAnimation(ivsecond,R.anim.rotation,60000);


    }
    private void makeAnimation(View view,int animID,int tg) {

        Animation animation= AnimationUtils.loadAnimation(bai3.this, animID);
        animation.setDuration(tg);
        view.startAnimation(animation);
    }
}