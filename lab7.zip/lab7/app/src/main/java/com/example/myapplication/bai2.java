package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class bai2 extends AppCompatActivity {
    ImageView ivall;
    Button btall,nobeta,doremon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);
        btall=findViewById(R.id.allimg);
        nobeta=findViewById(R.id.btnobita);
        doremon=findViewById(R.id.btdoremon);
        ivall=findViewById(R.id.ivall2);
        btall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImage("All");
            }
        });
        nobeta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImage("Nobita");
            }
        });
        doremon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImage("Doremon");
            }
        });

    }

    private void showImage(String img) {
        //hide img
        ObjectAnimator animator=ObjectAnimator.ofFloat(ivall, "translationX", 0f,500f);
        animator.setDuration(2000);
        ObjectAnimator animator1=ObjectAnimator.ofFloat(ivall, "alpha", 1f,0f);
        animator1.setDuration(2000);
        //show img
        ObjectAnimator animator2=ObjectAnimator.ofFloat(ivall, "translationX", -500f,0f);
        animator2.setDuration(2000);
        ObjectAnimator animator3=ObjectAnimator.ofFloat(ivall, "alpha", 0f,1f);
        animator3.setDuration(2000);
        //config slide show process to show next img
        AnimatorSet ans=new AnimatorSet();
        ans.play(animator2).with(animator3).after(animator).after(animator1);
        ans.start();
        final String imgName=img;
        animator1.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {
            }

            @Override
            public void onAnimationEnd(Animator animator) {

                if(imgName=="Nobita"){
                    ivall.setBackgroundResource(R.drawable.nobita);
                }
                if(imgName=="Doremon"){
                    ivall.setBackgroundResource(R.drawable.doraemon);
                }
                if(imgName=="All"){
                    ivall.setBackgroundResource(R.drawable.all);
                }
            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });

    }
}