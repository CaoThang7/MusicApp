package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class bai1_activity extends AppCompatActivity {
ImageView ivall;
Button btrotation,zoom,move;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1_activity);
        btrotation=findViewById(R.id.btrotation);
        zoom=findViewById(R.id.btzoom);
        move=findViewById(R.id.btmove);
        ivall=findViewById(R.id.ivall);

        btrotation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                makeAnimation(ivall,R.anim.rotation);
            }
        });
        move.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                makeAnimation(ivall,R.anim.move);
            }
        });
        zoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                makeAnimation(ivall,R.anim.zoom);
            }
        });

    }

    private void makeAnimation(View view,int animID) {

        Animation animation=AnimationUtils.loadAnimation(bai1_activity.this
                , animID);

        view.startAnimation(animation);
    }
}